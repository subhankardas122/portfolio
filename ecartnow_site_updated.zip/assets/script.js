// Placeholder for small interactions if needed later.
